import './style.css';
import { auth, registerCustomer, login, registerSeller, loadApprovedProducts, signOut, onAuthStateChanged } from './firebase.js';

const sampleProducts = [
 {id:'demo1',name:'Classic Cotton Shirt',category:'Clothing',price:699,old:999,vendor:'Urban Threads',emoji:'👕'},
 {id:'demo2',name:'Everyday Sneakers',category:'Shoes',price:1299,old:1799,vendor:'StepUp Store',emoji:'👟'},
 {id:'demo3',name:'Classic Frame Glasses',category:'Eyewear',price:499,old:799,vendor:'Vision Hub',emoji:'🕶️'},
 {id:'demo4',name:'Minimal Wrist Watch',category:'Watches',price:999,old:1499,vendor:'TimeCraft',emoji:'⌚'},
 {id:'demo5',name:'Everyday Leather Belt',category:'Accessories',price:399,old:599,vendor:'Urban Threads',emoji:'🧷'},
 {id:'demo6',name:'Printed Casual Kurti',category:'Clothing',price:799,old:1199,vendor:'Style Bazaar',emoji:'🥻'},
 {id:'demo7',name:'Running Sports Shoes',category:'Shoes',price:1599,old:2199,vendor:'StepUp Store',emoji:'👟'},
 {id:'demo8',name:'Polarized Sunglasses',category:'Eyewear',price:649,old:999,vendor:'Vision Hub',emoji:'😎'}
];
let products=[...sampleProducts], active='All', queryText='', cart=JSON.parse(localStorage.getItem('zyro-cart')||'[]'), page='home', currentUser=null;
const cats=['All','Clothing','Shoes','Eyewear','Watches','Accessories'];
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN');
function save(){localStorage.setItem('zyro-cart',JSON.stringify(cart))}
function count(){return cart.reduce((s,x)=>s+x.qty,0)}
function header(){return `<header><div class="brand"><span class="brandmark">Z</span><div><b>ZyroMart</b><small>EVERYTHING, ONE PLACE</small></div></div><div class="head-actions"><button class="accountbtn" id="accountBtn">${currentUser?'Account':'Login'}</button><button class="cartbtn" id="cartBtn">🛒 <span>Cart (${count()})</span></button></div></header>`}
function render(){
 const app=document.querySelector('#app');
 app.innerHTML=header()+(page==='cart'?cartPage():page==='seller'?sellerPage():page==='auth'?authPage():page==='account'?accountPage():homePage())+
 `<nav><button data-page="home" class="${page==='home'?'sel':''}">⌂<small>Home</small></button><button data-page="seller" class="${page==='seller'?'sel':''}">▣<small>Sell</small></button><button data-page="cart" class="${page==='cart'?'sel':''}">🛒<small>Cart</small></button></nav>`;
 document.querySelector('#cartBtn').onclick=()=>{page='cart';render()};
 document.querySelector('#accountBtn').onclick=()=>{page=currentUser?'account':'auth';render()};
 document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{page=b.dataset.page;render()});
 document.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{active=b.dataset.cat;render()});
 document.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>add(b.dataset.add));
 const search=document.querySelector('#search'); if(search){search.value=queryText;search.oninput=e=>{queryText=e.target.value;renderProducts()}}
 const loginForm=document.querySelector('#loginForm'); if(loginForm) loginForm.onsubmit=handleLogin;
 const signupForm=document.querySelector('#signupForm'); if(signupForm) signupForm.onsubmit=handleSignup;
 const sellerForm=document.querySelector('#sellerForm'); if(sellerForm) sellerForm.onsubmit=handleSeller;
 const logout=document.querySelector('#logout'); if(logout) logout.onclick=async()=>{await signOut(auth);page='home';render()};
}
function homePage(){return `<main><section class="hero"><div class="eyebrow">DISCOVER THE NEW WAY TO SHOP</div><h1>Good finds.<br><em>Great prices.</em></h1><p>Shop trusted independent stores, all in one place.</p><div class="hero-pills"><span>✦ Multiple sellers</span><span>✦ Easy shopping</span></div></section>
<div class="searchwrap"><span>⌕</span><input id="search" placeholder="Search clothes, shoes, watches..."></div>
<section class="section"><div class="sectionhead"><div><small>SHOP BY COLLECTION</small><h2>Categories</h2></div></div><div class="chips">${cats.map(c=>`<button data-cat="${c}" class="${active===c?'active':''}">${c}</button>`).join('')}</div></section>
<section class="section"><div class="sectionhead"><div><small>HANDPICKED FOR YOU</small><h2>Popular products</h2></div><span class="muted">${products.length} items</span></div><div id="products" class="productgrid">${productCards()}</div><p class="muted" id="productSource">Demo products are shown until approved seller listings are added.</p></section>
<section class="trust"><b>Shopping made simpler</b><p>Discover products from multiple independent sellers, all in one marketplace.</p></section></main>`}
function productCards(){return products.filter(p=>(active==='All'||p.category===active)&&(p.name+' '+(p.vendor||'')+' '+p.category).toLowerCase().includes(queryText.toLowerCase())).map(p=>`<article class="product"><div class="productpic">${p.emoji||'🛍️'}<span class="tag">ZyroMart</span></div><div class="productinfo"><small>${p.vendor||'Marketplace seller'}</small><b>${p.name}</b><div class="prices"><strong>${money(p.price)}</strong>${p.old?`<del>${money(p.old)}</del>`:''}</div><button class="add" data-add="${p.id}">Add to cart</button></div></article>`).join('')||'<p class="muted">No matching products found.</p>'}
function renderProducts(){const el=document.querySelector('#products');if(el){el.innerHTML=productCards();el.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>add(b.dataset.add))}}
function add(id){const item=cart.find(x=>x.id===id);item?item.qty++:cart.push({id,qty:1});save();render()}
function cartPage(){const rows=cart.map(x=>{const p=products.find(p=>p.id===x.id)||sampleProducts.find(p=>p.id===x.id);if(!p)return '';return `<div class="cartrow"><span class="cartemoji">${p.emoji||'🛍️'}</span><div class="cartdetail"><b>${p.name}</b><small>${p.vendor||'Marketplace seller'}</small><strong>${money(p.price)}</strong><div class="qty"><button data-dec="${p.id}">−</button><span>${x.qty}</span><button data-inc="${p.id}">+</button><button class="remove" data-remove="${p.id}">Remove</button></div></div></div>`}).join('');
const total=cart.reduce((s,x)=>{const p=products.find(p=>p.id===x.id)||sampleProducts.find(p=>p.id===x.id);return s+(p?Number(p.price)*x.qty:0)},0);
return `<main class="page"><small class="kicker">YOUR BAG</small><h1>Your cart</h1>${rows||'<div class="empty">🛍️<h3>Your cart is empty</h3><p>Find something you love.</p><button class="primary" id="shop">Continue shopping</button></div>'}${rows?`<div class="total"><span>Subtotal</span><b>${money(total)}</b></div><p class="notice">Checkout is not connected to real orders or payments yet.</p><button class="primary" id="checkout">Continue to checkout</button>`:''}</main>`}
function authPage(){return `<main class="page"><small class="kicker">YOUR ZYROMART ACCOUNT</small><h1>Welcome</h1><div class="sellerbox"><h2>Login</h2><form id="loginForm" class="form"><input name="email" type="email" placeholder="Email address" required><input name="password" type="password" placeholder="Password" minlength="6" required><button class="primary">Login</button></form></div><div class="sellerbox"><h2>Create customer account</h2><form id="signupForm" class="form"><input name="name" placeholder="Full name" required><input name="email" type="email" placeholder="Email address" required><input name="phone" placeholder="Phone (optional)"><input name="password" type="password" placeholder="Password (minimum 6 characters)" minlength="6" required><button class="primary">Create account</button></form></div><p id="authMsg" class="muted"></p></main>`}
function accountPage(){return `<main class="page"><small class="kicker">ACCOUNT</small><h1>Hello, ${escapeHtml(currentUser?.displayName||currentUser?.email||'Customer')}</h1><p class="lead">You are signed in with Firebase Authentication.</p><button class="primary" id="logout">Log out</button></main>`}
function sellerPage(){return `<main class="page"><small class="kicker">SELL ON ZYROMART</small><h1>Grow your store.</h1><p class="lead">Apply to become a marketplace seller. Admin approval is required before selling.</p>${currentUser?`<div class="sellerbox"><h2>Seller application</h2><form id="sellerForm" class="form"><input name="storeName" placeholder="Store name" required><input name="ownerName" placeholder="Owner name" required><input name="email" type="email" placeholder="Contact email" value="${escapeAttr(currentUser.email||'')}" required><input name="phone" placeholder="Phone number" required><button class="primary">Submit seller application</button></form><p id="sellerMsg" class="muted"></p></div>`:`<div class="sellerbox"><h2>Login required</h2><p>Sign in or create a customer account before applying as a seller.</p><button class="primary" id="goLogin">Login / Sign up</button></div>`}<div class="feature"><b>Seller benefits</b><p>• Store profile and product listings</p><p>• Order and inventory management (coming next)</p><p>• Sales and payout tracking (coming next)</p></div></main>`}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function escapeAttr(s){return escapeHtml(s)}
async function handleLogin(e){e.preventDefault();const f=new FormData(e.target);setMsg('authMsg','Logging in...');try{await login(f.get('email'),f.get('password'));page='account';render()}catch(err){setMsg('authMsg',friendly(err))}}
async function handleSignup(e){e.preventDefault();const f=new FormData(e.target);setMsg('authMsg','Creating account...');try{await registerCustomer({name:f.get('name'),email:f.get('email'),phone:f.get('phone'),password:f.get('password')});page='account';render()}catch(err){setMsg('authMsg',friendly(err))}}
async function handleSeller(e){e.preventDefault();const f=new FormData(e.target);setMsg('sellerMsg','Submitting application...');try{await registerSeller({storeName:f.get('storeName'),ownerName:f.get('ownerName'),email:f.get('email'),phone:f.get('phone')});setMsg('sellerMsg','Application submitted. Status: pending admin review.')}catch(err){setMsg('sellerMsg',friendly(err))}}
function setMsg(id,s){const el=document.getElementById(id);if(el)el.textContent=s}
function friendly(err){const code=err?.code||'';if(code.includes('email-already-in-use'))return 'यह ईमेल पहले से रजिस्टर है। Login करें।';if(code.includes('weak-password'))return 'कृपया मजबूत पासवर्ड रखें (कम से कम 6 अक्षर)।';if(code.includes('invalid-credential'))return 'ईमेल या पासवर्ड सही नहीं है।';if(code.includes('operation-not-allowed'))return 'Firebase Console में Email/Password sign-in चालू करें।';if(code.includes('permission-denied'))return 'Firestore Rules अनुमति नहीं दे रहे। Rules सेटअप जाँचें।';return err?.message||'कुछ गलत हुआ। फिर कोशिश करें।'}
document.addEventListener('click',e=>{
 const id=e.target.dataset.inc||e.target.dataset.dec||e.target.dataset.remove;
 if(id){const x=cart.find(x=>x.id===id);if(x){if(e.target.dataset.inc)x.qty++;else if(e.target.dataset.dec)x.qty--;else x.qty=0;}cart=cart.filter(x=>x.qty>0);save();render()}
 if(e.target.id==='shop'){page='home';render()}
 if(e.target.id==='checkout')alert('अभी वास्तविक checkout/payment चालू नहीं है। पहले सुरक्षित order backend और payment provider जोड़ना होगा।');
 if(e.target.id==='goLogin'){page='auth';render()}
});
onAuthStateChanged(auth,user=>{currentUser=user; if(document.querySelector('#app'))render()});
loadApprovedProducts().then(list=>{if(list.length){products=[...list,...sampleProducts];render()}}).catch(()=>{});
render();
