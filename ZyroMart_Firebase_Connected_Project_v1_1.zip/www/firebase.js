import { initializeApp } from 'firebase/app';
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, onAuthStateChanged, updateProfile
} from 'firebase/auth';
import {
  getFirestore, doc, setDoc, getDoc, collection, getDocs,
  query, where, serverTimestamp
} from 'firebase/firestore';

const firebaseConfig = {"apiKey":"AIzaSyB2awxO3Avio8LLWKJeWMCXuwwcFhq3Ar0","authDomain":"patnakart-6925b-5b441.firebaseapp.com","projectId":"patnakart-6925b-5b441","storageBucket":"patnakart-6925b-5b441.firebasestorage.app","messagingSenderId":"1053236001887","appId":"1:1053236001887:android:3bf6c81c6dd299715eefea"};
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export async function registerCustomer({name,email,password,phone}) {
  const cred = await createUserWithEmailAndPassword(auth,email,password);
  await updateProfile(cred.user,{displayName:name});
  await setDoc(doc(db,'users',cred.user.uid),{
    uid:cred.user.uid, name, email, phone:phone||'', role:'customer',
    createdAt:serverTimestamp()
  });
  return cred.user;
}
export async function login(email,password) {
  const cred = await signInWithEmailAndPassword(auth,email,password);
  return cred.user;
}
export async function registerSeller({storeName,ownerName,email,phone}) {
  const user = auth.currentUser;
  if (!user) throw new Error('पहले ग्राहक अकाउंट बनाकर लॉगिन करें।');
  await setDoc(doc(db,'sellerApplications',user.uid),{
    uid:user.uid, storeName, ownerName, email, phone:phone||'',
    status:'pending', createdAt:serverTimestamp()
  });
}
export async function loadApprovedProducts() {
  const q = query(collection(db,'products'),where('status','==','approved'));
  const snap = await getDocs(q);
  return snap.docs.map(d=>({id:d.id,...d.data()}));
}
export { signOut, onAuthStateChanged };
