# ZyroMart Android App — Firebase-connected starter (v1.1)

## इसमें क्या जोड़ा गया
- Firebase Authentication: email/password customer signup और login
- Firestore: customer profile save
- Seller application submit with `pending` status
- Approved products का Firestore read
- शुरुआती Firestore security rules (`firestore.rules`)
- Capacitor Android app configuration

## Firebase Console में जरूरी सेटिंग
1. Authentication → Sign-in method → Email/Password → Enable → Save.
2. Firestore Database → Create database. शुरुआत में production mode चुनें.
3. Rules tab में इस प्रोजेक्ट की `firestore.rules` सामग्री publish करें.
4. Firebase project settings में Android app package `com.zyromart.shop` होना चाहिए.

## Project configuration
Firebase web SDK config `www/firebase.js` में दिया गया है, उसी Firebase project से जो दिए गए `google-services.json` में था:
- Project ID: `patnakart-6925b-5b441`
- Android package: `com.zyromart.shop`

Firebase client API key ऐप में दिख सकती है; सुरक्षा Firestore Rules और backend permissions से आती है। Service account private key कभी client app में न रखें।

## Build
`npm install`
`npm run build`
फिर Android platform जोड़ने/सिंक करने के लिए build environment में:
`npx cap add android` (पहली बार)
`npx cap sync android`
Android Studio/Gradle से APK बनाएं।

यह ZIP signed APK नहीं है। Android build के लिए Android SDK/Gradle वाला कंप्यूटर या भरोसेमंद cloud build service चाहिए। केवल फोन पर APK बनना उपलब्ध editor/build service पर निर्भर है।

## अभी production में क्या बाकी है
- Seller approval के लिए trusted admin backend / custom claims
- Seller product create/edit/delete और inventory
- Admin dashboard
- Orders, order status, cancellations, refunds
- Payment gateway server integration and webhook verification
- Delivery management, notifications
- Privacy policy, terms, data deletion and production testing

Checkout जानबूझकर demo-only है; कोई वास्तविक भुगतान या ऑर्डर नहीं लिया जाता।
